<script setup>
definePageMeta({ layout: 'dashboard' })
</script>
<template><div class="p-4">Coming soon: ส่งออกข้อมูล</div></template>
