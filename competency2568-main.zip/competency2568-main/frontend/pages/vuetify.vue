<template>
  <div class="text-center">
    <v-progress-circular
      color="primary"
      indeterminate
    ></v-progress-circular>

    <v-progress-circular
      color="red"
      indeterminate
    ></v-progress-circular>

    <v-progress-circular
      color="purple"
      indeterminate
    ></v-progress-circular>

    <v-progress-circular
      color="green"
      indeterminate
    ></v-progress-circular>

    <v-progress-circular
      color="amber"
      indeterminate
    ></v-progress-circular>
  </div>
</template>
<style scoped>
.v-progress-circular {
  margin: 1rem;
}
</style>